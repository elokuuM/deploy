"""ppq/tests contains all PPQ test scripts, all scripts are manage by pytest.

We start building this test collection since ppq 0.6.2 you are welcome to
contribute codes to this collection.
"""
